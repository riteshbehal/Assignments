﻿using Amazon;
using Amazon.Runtime;
using Amazon.SQS;
using Amazon.SQS.Model;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        SendMessage();

        Console.ReadLine();
    }


    private static async Task SendMessage()
    {
        string accessKey = "AKIA2QIPEN4XYIYSRFFD";
        string secret = "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";
        string queueUrl = "https://sqs.ap-south-1.amazonaws.com/722123124527/transactionsQueue";
        string awsregion = "ap-south-1";

        BasicAWSCredentials creds = new BasicAWSCredentials(accessKey, secret);

        RegionEndpoint region = RegionEndpoint.GetBySystemName(awsregion);

        SendMessageRequest sendMessageRequest = new SendMessageRequest(queueUrl, "From App1");

        var sqsClient = new AmazonSQSClient(creds, region);

        var data = await sqsClient.SendMessageAsync(sendMessageRequest);
    }
}