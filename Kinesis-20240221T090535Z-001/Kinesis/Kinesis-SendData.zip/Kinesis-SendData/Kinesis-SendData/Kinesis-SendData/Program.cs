﻿using Amazon;
using Amazon.Kinesis;
using Kinesis_SendData;
using Amazon.Kinesis.Model;
using Newtonsoft.Json;
using System.Text;

var kinesisClient = new AmazonKinesisClient(RegionEndpoint.APSouth1);

for (int i = 1; i <= 5; i++)
{
    Logdata data=new Logdata();
    data.logId = i;
    data.logDetails= $"LogDetails{i}";

    // We need to convert our data into bytes
    byte[] RequestInBytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data));

    using (MemoryStream ms = new MemoryStream(RequestInBytes))
    {
        var recordRequest = new PutRecordRequest()
        {
            StreamName = "demostream",
            PartitionKey = Convert.ToString(data.logId),
            Data = ms
        };

        var response = await kinesisClient.PutRecordAsync(recordRequest);
        Console.WriteLine("Record written to stream");
        Console.WriteLine($"Sequence Number {response.SequenceNumber}");
        
    }
    }





