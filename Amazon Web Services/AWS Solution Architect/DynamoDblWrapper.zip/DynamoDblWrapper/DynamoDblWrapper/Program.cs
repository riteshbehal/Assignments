﻿


using System.Reflection.Metadata;

// See https://aka.ms/new-console-template for more information
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Runtime;
using System.Configuration;
using System.Reflection.Metadata;
using Document = Amazon.DynamoDBv2.DocumentModel.Document;
using System.Runtime.CompilerServices;

class MidlevelItemCRUD
{
    private static string tableName = "ProductsData";
    // The sample uses the following id PK value to add book item.
    private static int sampleBookId = 557;
    static void Main(string[] args)
    {
        //RetrieveBook();
        DeleteBook();
        // See https://aka.ms/new-console-template for more information
        //CreateBookItem();
        Console.WriteLine("Hello, World!");
        Console.ReadLine();
    }


    private static void CreateBookItem()
    {
        RegionEndpoint regionEndPoint = RegionEndpoint.GetBySystemName(ConfigurationManager.AppSettings["AWSRegion"]);
        var awsCredentials = new Amazon.Runtime.BasicAWSCredentials("AKIA2QIPEN4X45NI4FQ4", "S3ioRTcRnRl/l+ZVn1LHtL+h6y0VjQFsgS73s2/F");

        AmazonDynamoDBClient client = new AmazonDynamoDBClient(awsCredentials, regionEndPoint);
        Table productCatalog = Table.LoadTable(client, tableName);

        int sampleBookId = 560;
        Console.WriteLine("\n*** Executing CreateBookItem() ***");
        var book = new Document();
        book["Id"] = sampleBookId;
        book["Title"] = "Book " + sampleBookId;
        book["Price"] = 40;
        book["ISBN"] = "111-3333333";
        book["Authors"] = new List<string> { "Author 12", "Author 22", "Author 32" };
        book["PageCount"] = 400;
        book["Dimensions"] = "8.5x11x.5";
        book["InPublication"] = new DynamoDBBool(true);
        book["InStock"] = new DynamoDBBool(false);
        book["QuantityOnHand"] = 0;

        productCatalog.PutItemAsync(book);
    }

    private static void RetrieveBook()
    {
        RegionEndpoint regionEndPoint = RegionEndpoint.GetBySystemName(ConfigurationManager.AppSettings["AWSRegion"]);
        var awsCredentials = new Amazon.Runtime.BasicAWSCredentials("AKIA2QIPEN4X45NI4FQ4", "S3ioRTcRnRl/l+ZVn1LHtL+h6y0VjQFsgS73s2/F");

        AmazonDynamoDBClient client = new AmazonDynamoDBClient(awsCredentials, regionEndPoint);
        Table productCatalog = Table.LoadTable(client, tableName);

        int sampleBookIdToRetrive = 559;
        Console.WriteLine("\n*** Executing RetrieveBook() ***");
        // Optional configuration.
        GetItemOperationConfig config = new GetItemOperationConfig
        {
            AttributesToGet = new List<string> { "Id", "ISBN", "Title", "Authors", "Price" },
            ConsistentRead = true
        };
        Document document = productCatalog.GetItemAsync(sampleBookIdToRetrive, config).Result;

        Console.WriteLine("RetrieveBook: Printing book retrieved...");

        PrintDocument(document);
    }

    private static void PrintDocument(Document updatedDocument)
    {
        foreach (var attribute in updatedDocument.GetAttributeNames())
        {
            string stringValue = null;
            var value = updatedDocument[attribute];
            if (value is Primitive)
                stringValue = value.AsPrimitive().Value.ToString();
            else if (value is PrimitiveList)
                stringValue = string.Join(",", (from primitive
                                in value.AsPrimitiveList().Entries
                                                select primitive.Value).ToArray());
            Console.WriteLine("{0} - {1}", attribute, stringValue);
        }
    }

    private static void DeleteBook()
    {
        int sampleBookIdtoDelete = 2;
        RegionEndpoint regionEndPoint = RegionEndpoint.GetBySystemName(ConfigurationManager.AppSettings["AWSRegion"]);
        var awsCredentials = new Amazon.Runtime.BasicAWSCredentials("AKIA2QIPEN4X45NI4FQ4", "S3ioRTcRnRl/l+ZVn1LHtL+h6y0VjQFsgS73s2/F");

        AmazonDynamoDBClient client = new AmazonDynamoDBClient(awsCredentials, regionEndPoint);
        Table productCatalog = Table.LoadTable(client, tableName);

        Console.WriteLine("\n*** Executing DeleteBook() ***");
        // Optional configuration.
        DeleteItemOperationConfig config = new DeleteItemOperationConfig
        {
            // Return the deleted item.
            ReturnValues = ReturnValues.AllOldAttributes
        };
        Document document = productCatalog.DeleteItemAsync(sampleBookIdtoDelete, config).Result;
        Console.WriteLine("DeleteBook: Printing deleted just deleted...");
        PrintDocument(document);
    }
}